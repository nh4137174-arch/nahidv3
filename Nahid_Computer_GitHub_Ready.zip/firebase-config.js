/* Nahid Computer Firebase Web App config. Public web config only; never add service-account private keys here. */
export const firebaseConfig = {
  apiKey: "AIzaSyDS-SvMxcbTnKQrVFfOSS3GrusvjquLhF8",
  authDomain: "nahidv2.firebaseapp.com",
  projectId: "nahidv2",
  storageBucket: "nahidv2.firebasestorage.app",
  messagingSenderId: "889156174938",
  appId: "1:889156174938:web:0c4b1011fc4ceada720463",
  measurementId: "G-SX8T2G8T4R"
};

export const BKASH_MERCHANT_NUMBER = "01324392059";
